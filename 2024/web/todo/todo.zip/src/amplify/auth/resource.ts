import { defineAuth } from '@aws-amplify/backend';

/**
 * Define and configure your auth resource
 * @see https://docs.amplify.aws/gen2/build-a-backend/auth
 */

// TODO: Create admin group for admin@ggc.tf user to make administration easier.
export const auth = defineAuth({
  loginWith: {
    email: true,
  },
});
