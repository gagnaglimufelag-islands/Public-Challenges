export default async function Flag() {
  return (
    <div className="flag-container">
      <h2 className="flag-title">Flag</h2>
      <p className="flag-text">Welcome, here is your flag: {"flag{not-a-flag}"}</p>
    </div>
  );
}
