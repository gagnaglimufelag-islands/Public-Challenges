from wat import wat
from why import why
from how import how
from when import when
from who import who
from rotate import rotate
from enc import enc
from encr import encr
from renc import renc

flag = [227, 233, 240, 18, 103, 157, 163, 127, 224, 10, 159, 158, 169, 210, 145, 92, 81, 29, 160]

wat(flag)
why(flag)
how(flag)
when(flag)
who(flag)
rotate(flag)
enc(flag)
encr(flag)
renc(flag)

print(bytes(flag))
