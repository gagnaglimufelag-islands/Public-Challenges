from who import who
from rotate import rotate
from how import how
from renc import renc
from wat import wat

flag = [211, 198, 0, 196, 32, 196, 122, 251, 91, 70, 178, 37, 165, 162, 239, 245, 71, 66, 182, 98, 166, 221, 1, 37, 216, 82, 71, 78, 250, 5]

who(flag)
rotate(flag)
how(flag)
renc(flag)
wat(flag)

print(bytes(flag))
