namespace App.Models;

public class PostcodeInput
{
    public string? Postcode { get; set; }
}