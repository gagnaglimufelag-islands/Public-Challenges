using System.Diagnostics;

public class Postcode
{
    public int Id { get; set; }
    public string? Name { get; set; }
    public bool Hidden { get; set; }
}